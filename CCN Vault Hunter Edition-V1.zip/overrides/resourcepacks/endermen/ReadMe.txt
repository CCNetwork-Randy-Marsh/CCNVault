----------------------------------------
THOROLHUGIL'S Energized Enderman (REQUIRES OPTIFINE)
----------------------------------------

This pack consists of a new texture for the enderman by reddit user Thorolhugil, as seen in the link below. It does not affect the default enderman texture, but adds the glowing and nether endermen as a possible texture they can spawn with.

- Endermen that spawn in the overworld have a 50% chance to be glowing, 50% to be default.
- Endermen in the End have an 80% chance to be glowing.
- Endermen that spawn in the nether have a 50% chance to be fiery (just a texture, no gameplay effect).

- You can name them with a nametag and include the word 'radiant' to get a glowing one.
- You can name them with a nametag and include the word 'fiery' to get a nether one.

reddit post:
https://redd.it/d04iqz

--------------------------